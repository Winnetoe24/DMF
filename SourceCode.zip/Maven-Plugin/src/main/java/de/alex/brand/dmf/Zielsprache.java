package de.alex.brand.dmf;

public enum Zielsprache {
    JAVA,
    TYPESCRIPT,
    SQL
}
