package de.alexbrand.dmf;

import org.eclipse.lsp4j.services.LanguageServer;

public interface DMFServerAPI extends LanguageServer {
}
