package base

type TreeCleaner interface {
	CleanTreeReferences()
}
