package gbase

import "github.com/Winnetoe24/DMF/semantic/semantic-parse/smodel/packages"

type VariableKontext struct {
	Variable      packages.Variable
	ImportKontext ImportKontext
}
