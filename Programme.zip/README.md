# Übersicht über die enthaltenen Programme
1. lsp => Linux Build des LSP-Servers
2. lsp.exe => Windows Build des LSP-Servers
3. generator => Linux Build des Generators
4. generator.exe => Windows Build des Generators
5. relay => Linux Build des Relays zur Nutzung eines LSP-Servers, der über TCP kommuniziert, über stdio
6. generator.exe => Windows Build des Relays zur Nutzung eines LSP-Servers, der über TCP kommuniziert, über stdio
7. dmf-generator-plugin-0.0.1-SNAPSHOT.jar => Das Maven Plugin des DMF
8. DMF-1.0.0.vsix => Visual Studio Code Plugin
9. dmf-plugin-1.0-SNAPSHOT.zip => Intellij Plugin
