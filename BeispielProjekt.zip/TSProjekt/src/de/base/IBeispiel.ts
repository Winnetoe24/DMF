export interface IBeispiel {
    
    printBeispielMarkdown(): string;
}