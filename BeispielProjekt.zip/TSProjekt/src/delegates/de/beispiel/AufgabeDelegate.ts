import { Aufgabe } from "../../../de/beispiel/Aufgabe";
import { Beispiel } from "../../../de/beispiel/Beispiel";


