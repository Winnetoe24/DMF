package de.beispiel;

/**
 * Delegate von Aufgabe
 * Wird nur initial generiert.
 * Methoden müssen implementiert werden.
 **/
public class AufgabeDelegate {

}